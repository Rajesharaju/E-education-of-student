package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.demo.model.Student;
import com.example.demo.repository.StudentRepository;

@SpringBootApplication
public class StudentbootApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(StudentbootApplication.class, args);
	}
	
	@Autowired
	StudentRepository repository;
	
	@Override
	public void run(String... args)throws Exception
	{
		this.repository.save(new Student("dd","ss","ws","hehde"));
		this.repository.save(new Student("d1","rs","w4","he56e"));
		this.repository.save(new Student("d2","s5","w6","he78e"));
		
		
		
	}

}
